# PROMPTS — show-tell-tripmate-pitch

No generation prompts. Every frame is drawn in Manim from `scenes.py`; no image, video or voice
generator was prompted. Narration is read by local Kokoro (`am_onyx`). The prompts and commands that
rebuild the film are in BUILD-PROMPT.md.
