# TYPECHECK.md — GATE T

Reel: `show-tell-tripmate-pitch`  |  Checked: 2026-10-24T17:27  |  Overall: PASS  |  Beats checked: 32  |  FAILs: 0

Spec: `skills/make/kerning/reference/type-spec.md` §8.  Floor: 1.9% frame-height.  Contrast: 4.5:1 WCAG.  Kern threshold: 3.5× expected advance.  Wordy budget: 2 elements.

| beat | lane | polarity | worst finding | status | fix |
|------|------|----------|---------------|--------|-----|
| B01 | manim | light | min-size §8.1: min text-run height 53px >= floor 41px (individual-char fallback at 2×) | PASS | — |
| B02 | manim | light | min-size §8.1: min text-run height 302px >= floor 41px | PASS | — |
| B03 | manim | light | min-size §8.1: min text-run height 173px >= floor 41px | PASS | — |
| B04A | manim | light | min-size §8.1: min text-run height 50px >= floor 41px | PASS | — |
| B04B | manim | light | min-size §8.1: min text-run height 53px >= floor 41px (individual-char fallback at 2×) | PASS | — |
| B04C | manim | light | min-size §8.1: min text-run height 53px >= floor 41px (individual-char fallback at 2×) | PASS | — |
| B04D | manim | light | min-size §8.1: min text-run height 53px >= floor 41px (individual-char fallback at 2×) | PASS | — |
| B04 | manim | light | min-size §8.1: min text-run height 53px >= floor 41px (individual-char fallback at 2×) | PASS | — |
| B05 | manim | light | min-size §8.1: min text-run height 53px >= floor 41px | PASS | — |
| B06 | manim | light | min-size §8.1: min text-run height 223px >= floor 41px | PASS | — |
| B07 | manim | light | min-size §8.1: min text-run height 53px >= floor 41px | PASS | — |
| B08 | manim | light | min-size §8.1: min text-run height 187px >= floor 41px (individual-char fallback at 2×) | PASS | — |
| B09 | manim | light | min-size §8.1: min text-run height 53px >= floor 41px (individual-char fallback at 2×) | PASS | — |
| B10 | manim | light | min-size §8.1: min text-run height 54px >= floor 41px | PASS | — |
| B11 | manim | light | min-size §8.1: min text-run height 62px >= floor 41px (individual-char fallback at 2×) | PASS | — |
| B12 | manim | light | min-size §8.1: min text-run height 60px >= floor 41px (individual-char fallback at 2×) | PASS | — |
| B13 | manim | light | min-size §8.1: min text-run height 54px >= floor 41px | PASS | — |
| B14 | manim | light | min-size §8.1: min text-run height 47px >= floor 41px | PASS | — |
| B15 | manim | light | min-size §8.1: min text-run height 54px >= floor 41px | PASS | — |
| B16 | manim | light | min-size §8.1: min text-run height 203px >= floor 41px | PASS | — |
| B17 | manim | light | min-size §8.1: min text-run height 195px >= floor 41px | PASS | — |
| B18 | manim | light | min-size §8.1: min text-run height 53px >= floor 41px (individual-char fallback at 2×) | PASS | — |
| B19 | manim | light | min-size §8.1: min text-run height 155px >= floor 41px | PASS | — |
| B20 | manim | light | min-size §8.1: min text-run height 53px >= floor 41px (individual-char fallback at 2×) | PASS | — |
| B21 | manim | light | min-size §8.1: min text-run height 53px >= floor 41px (individual-char fallback at 2×) | PASS | — |
| B22 | manim | light | min-size §8.1: min text-run height 478px >= floor 41px | PASS | — |
| B23 | manim | light | min-size §8.1: min text-run height 201px >= floor 41px | PASS | — |
| B24 | manim | light | min-size §8.1: min text-run height 276px >= floor 41px | PASS | — |
| B25 | manim | light | min-size §8.1: min text-run height 59px >= floor 41px | PASS | — |
| B26 | manim | light | min-size §8.1: min text-run height 59px >= floor 41px | PASS | — |
| B27 | manim | light | min-size §8.1: min text-run height 54px >= floor 41px | PASS | — |
| BOUT | manim | light | min-size §8.1: min text-run height 90px >= floor 41px | PASS | — |

---

## Failures requiring action before cut

*None — GATE T PASS.*
---

## Check summary

| Check | Beats checked | FAILs |
|-------|---------------|-------|
| no-wordy-card §8.5 | 0 | 0 |
| min-size §8.1 | 32 | 0 |
| overflow §8.2 | 32 | 0 |
| contrast §8.3 | 32 | 0 |
| contrast-local §8.3b | 32 | 0 |
| bbox-overlap §8.6b | 32 | 0 |
| card-clip §8.13 | 32 | 0 |
| kerning §8.4 | 32 | 0 |
| redundancy §8.10 (advisory) | 0 | 0 (advisory — no exit effect) |

---

*GATE T: any FAIL blocks `./art run` and `./art final`. Fix the flagged beats and re-run `scripts/type_check.py` until green.*
