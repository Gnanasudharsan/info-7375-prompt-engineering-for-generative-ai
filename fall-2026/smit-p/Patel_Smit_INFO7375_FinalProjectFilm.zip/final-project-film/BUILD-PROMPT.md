# BUILD-PROMPT — show-tell-tripmate-pitch

## Executive summary

This file lists the requests and commands that produced the TripMate pitch film, in order, so anyone
can rebuild it. Everything runs locally and for free: no paid generation, no API keys, no uploads.

## 1. The request (Smit Patel to Claude Code, 2026-10-23)

> Create a video for this project [the TripMate project document]. In the video, tell everything that
> is possible; we can remove things during the project. Don't miss anything this time. [Followed by
> the full Final Project Pitch Film assignment text.]

Claude's working instructions, as agreed in the session:

1. Answer the assignment's seven questions in order, one picture and one idea per beat.
2. Cover the whole feature list, with the extras marked "if time allows", and keep the film under four
   minutes.
3. Honesty rule: past tense only for what exists (the brief and one real route sample); label every
   mock-up "constructed" on screen; no invented users, results or Claude responses.
4. Name two real alternatives, checked by web search, and say what TripMate does that they do not.

**Second request (2026-10-23):** add the best travel mode for the budget, AI hotel search under budget,
and an AI places-to-see plan for Goa from the user's preferences; explain why the hiring manager is a
reader. Result: three new beats (B04A, B04B, B04C), B11 says the hiring manager reads it because this is
a portfolio piece, and fourteen lines were tightened to keep the film under four minutes. Version 1
(3:52) is archived in `_superseded/v1-2026-10-23/`.

**Third request (2026-10-23):** remove the hiring manager; the project will build every feature and
use Google APIs for hotel and flight prices; the main point is the whole trip (places and activities
at the destination), not only road journeys. Result: the script was rewritten around the whole trip
(new beat B04D for the day plan; B07 now compares Wanderlog and Roadtrippers; B11 names only the
traveller; the target role moved to B24; the first piece is now the plan checker). Claude checked the
Google claim before writing it: Google has no public flight or hotel price API (QPX Express closed in
2018) and Amadeus closed its free developer APIs on July 17, 2026, so the film names this as the risk
(B22) and the plan (B23) instead. Version 2 is archived in `_superseded/v2-2026-10-23/`.

**Fourth request (2026-10-24):** "I don't have anything [built]; I have knowledge of these things;
everything needs to be built from scratch." Result: B24 and B25 rewritten (mostly learning; no public
projects yet), co-op and repository claims removed.

## 2. The real route sample (B09)

```bash
curl -s "https://router.project-osrm.org/route/v1/driving/72.5714,23.0225;73.8278,15.4909?overview=false" \
  -o evidence/osrm-ahmedabad-panaji-2026-10-23.json
```

Result: 1,035.7 km, 12.7 h of driving (OSRM estimate, no traffic, no breaks).

## 3. Build the film

Run from this folder, with `ART=<path to brutalist.art>`:

```bash
python3 make_sheet.py                                         # beat_sheet.json from the narration
python3 $ART/runtime/scripts/generate_audio_kokoro.py .        # local Kokoro voice, per-beat mp3
$ART/art run . --height 1080                                   # Gates L, A, W, B; render; Gate V
python3 $ART/runtime/scripts/type_check.py .       # GATE T (typography)
$ART/art final . --height 1080 --out final                     # verified master + .verified.json
```

`art run` needs `FACTCHECK.md`, `SHOTLIST.md` and `PROMPTS.md` to exist first (Gate F).

## 4. Fixes made to pass the gates (2026-10-23)

| Gate | Beat | Problem | Fix |
|---|---|---|---|
| — | all | first cut ran 4:08 | ten lines trimmed, 3:52 |
| F | — | paperwork missing | wrote FACTCHECK, SHOTLIST, PROMPTS |
| A | B09, B02 | shapes never changed | added a distance bracket and moving car; a trail and pin |
| B | B10 | "Ahmedabad" outside safe area | label moved inward |
| B | B17 | "save" sat on the window border | moved inside |
| render | B22 | dashed outline crashed on a group | dashed each face |
| V | B06, B13, B17, B18, B26 | low contrast, empty midpoint, late fades | darker blocks, earlier cues |
| T | B01 | terracotta read as accent text | pin and map route to ink |
| T | B23 | tag outline read as overlapping text | plain label |
| v2 render | B04A | "cost" and "time" labels outside the safe area | scene shifted right |
| v2 frame read | B04C | each day showed one icon twice | mixed icons per day |
| v2 GATE T | B02 | title not on screen at the midpoint | title shown from the start |
| v3 Gate A | B11 | shapes never changed | coins drop in with "on a budget" |
| v3 Gate V | B11 | near-empty frame at the midpoint | suitcase shown from the start |
| v3 frame read | B04, B08 | label and last tick appeared too late | drawn earlier |
| v3 GATE T | B09 | no text on screen at the midpoint | source caption shown from the start |
| frame read | B02, B11, B14, B15, B21 | faint pin, label on crate, late fade, tick and cross together, misleading "just over" tag | fixed in `scenes.py`, re-rendered |
