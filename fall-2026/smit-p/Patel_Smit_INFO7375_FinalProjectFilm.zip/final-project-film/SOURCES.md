# SOURCES — show-tell-tripmate-pitch

## Executive summary

This file says where every part of the TripMate pitch film came from: what Smit made, what Claude
contributed, which tools and data were used, and under what licence. The narration voice is synthetic
(a local text-to-speech model reading the script); this file is the disclosure.

## What I made (Smit Patel)

- The TripMate project document (given in chat, 2026-10-23): features, road-trip stopover planner,
  target users, architecture, MVP and success criteria. The idea started from one of Claude's
  suggestions (a trip planner called TripMate); I chose it and wrote the document.
- The choice to pitch the full feature list and trim later.
- Deciding TripMate plans the whole trip, not only road journeys; removing the hiring-manager reader;
  choosing to build every feature (2026-10-23).
- Asking for three more features in the film: the best travel mode for the budget, hotel search under
  budget, and a places-to-see plan built from preferences (2026-10-23).
- Rejecting my earlier ideas after the feedback; keeping the name TripMate; rejecting a
  route-finder-only focus (2026-10-23 to 10-24).
- Checking Wanderlog and Roadtrippers myself (2026-10-24), and asking for the film to be changed four
  times.

## What Claude contributed (Claude Opus 5.5, in Claude Code, 2026-10-23 to 10-24)

- Drafted the narration (`make_sheet.py`) and `PROJECT-BRIEF.md` from my project document and the
  assignment's seven questions. I reviewed each version and asked for changes four times (see
  FRICTIONAL.md).
- Researched the two alternatives (Wanderlog, Roadtrippers) and the data-access risk (Google, Amadeus)
  by web search; see FACTCHECK.md rows 1, 2, 5 and 6.
- Fetched the one real route sample (OSRM, row 3 of FACTCHECK.md) with a single `curl` request.
- Drew every scene in Manim (`scenes.py`), voiced the script with local Kokoro, ran the render and all
  quality gates, fixed what they flagged, and read the frames of every beat.
- Wrote this file, README.md, BUILD-PROMPT.md, FACTCHECK.md and the factual entries in FRICTIONAL.md.
  The reflection lines in FRICTIONAL.md are my answers to Claude's questions (2026-10-24), placed in
  the file by Claude with only spelling and grammar fixed.

## Tools and data

| Item | Where | Licence / owner |
|---|---|---|
| Toolkit: `show-tell` skill, drawing kit, render gates | `brutalist.art` (instructor-provided) | instructor's toolkit |
| Manim Community v0.18.1 | pip | MIT |
| Narration voice | Kokoro-82M (local), voice `am_onyx` | Apache-2.0 |
| Font | EB Garamond | SIL OFL |
| Route sample (B09) | OSRM demo server, router.project-osrm.org, fetched 2026-10-23T20:42Z | route data © OpenStreetMap contributors, ODbL |
| Roadtrippers facts (B07) | support.roadtrippers.com, "Planning a Trip on Our Website"; forum.roadtrippers.com, "Can I edit hours to drive for each day individually?" | named for comparison only |
| Wanderlog facts (B07) | wanderlog.com (trip planner, travel map and AI assistant pages; budget feature); Wanderlog co-founder's blog post on the AI assistant | named for comparison only |
| Google API facts (B22) | Google Maps Platform pricing pages (Places API, Routes API); Digital Trends and TechTimes on the QPX Express shutdown (2018); Duffel blog, "Google Flights API" | named for the risk only |
| Amadeus fact (B22) | PhocusWire, "Amadeus to shut down self-service APIs portal for developers" (July 17, 2026) | named for the risk only |

**Third-party assets:** none beyond the tools above. Every drawing is original Manim code in
`scenes.py`. No stock images, music, icons or footage.

**Synthetic narration disclosure:** the voice is Kokoro `am_onyx` reading the script. The film does not
say so, to keep it on the pitch; this file is the disclosure.

**Private data:** none. No résumé, contacts, application tracker or conversation transcripts are in
the film or this folder.
