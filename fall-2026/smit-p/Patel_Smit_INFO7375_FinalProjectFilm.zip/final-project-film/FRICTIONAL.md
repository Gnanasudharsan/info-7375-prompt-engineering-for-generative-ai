# FRICTIONAL — TripMate final project pitch film (Smit Patel, INFO 7375)

---

## 2026-10-21 — regrade of my first pitch (OrderTrail, 36/50)

- **What happened:** my first pitch (OrderTrail, a material-order tracker for small construction
  companies) got 36/50. Deductions: no specific detail on the alternatives; the film ran 4:20; my
  reflections were drafts I had not rewritten. Claude recut that film to 3:52 and cleared the drafted
  reflections.
- **Evidence:** `youtube/show-tell-ordertrail-pitch/` and its `_superseded/v2-graded-2026-10-11/`.
- **What I thought:** I was not able to convey my idea properly in the video, and I realized I need
  to work more on the project pitch.

## 2026-10-21 to 10-23 — changing my project

- **What happened:** I decided to leave OrderTrail and look for a new idea. Ideas discussed with
  Claude and dropped: a self-hosted ticket tracker with agents, Sponsor Check, text-to-SQL,
  ProofReview (an AI code reviewer that proves bugs), a multi-agent ticket board, ClassCatch,
  SubSpy, SnapIt, SplitSnap, AppTrack, ScamCheck, and a LinkedIn automation tool. I chose TripMate and
  wrote the project document myself.
- **Project change (logged as the assignment asks):** OrderTrail → TripMate, 2026-10-23.
- **Why I picked TripMate over the others:** my previous idea had problems with finding data, so I
  went with TripMate. Finding information and making a good trip plan is a genuine problem.

## 2026-10-23 — research and the one real data point

- **Claude's contribution:** web search on Wanderlog, Roadtrippers, Google's travel APIs and Amadeus
  (FACTCHECK rows 1, 2, 5, 6); one OSRM request for Ahmedabad to Goa: 1,035.7 km, 12.7 h of driving.
- **What I checked myself (2026-10-24):** Wanderlog was not showing the best route for my trip, and
  it did not suggest how my day looks at the destination; I need to select the places myself. In my case,
  TripMate will suggest a good city to stop in. Roadtrippers was not working for Indian cities.
- **Evidence:** `evidence/osrm-ahmedabad-panaji-2026-10-23.json`, `evidence/fetched_at.txt`.

## 2026-10-23 — building the film

- **What happened:** Claude drafted the script from my document and the seven questions, drew 28
  scenes, voiced them locally, and ran the gates. The first cut ran 4:08 and was trimmed to 3:52. Runs 1
  to 9 each stopped on a gate failure or a crash, GATE T then failed twice, and Claude's own frame read
  found 5 more problems the gates passed; all were fixed (list in BUILD-PROMPT.md section 4).
- **Friction:** Gate A checks each scene in an isolated copy without the beat sheet, so B02 passed
  when checked normally but failed in the gate. Reproducing the isolated check found it.
- **Evidence:** `logs/run1.log` … `logs/run13.log` (render logs, progress bars stripped), `_qc/REPORT.md`, `layout_audit.md`, `TYPECHECK.md`.
- **Does the film say what I mean, in words I would use?** I already changed it multiple times.

## 2026-10-23 — second version: three features I asked for

- **What happened:** after watching version 1, I asked for three things it was missing: the best
  travel mode for the budget, AI hotel search under budget, and an AI plan of places to see in Goa from
  my preferences. I also asked why the hiring manager was in the film. Claude explained the assignment
  requires a target role and reader (question 3) and changed B11 to say why. Claude added three beats,
  tightened fourteen lines to stay under four minutes (3:54), re-rendered all 31 scenes and re-ran the
  gates.
- **Evidence:** `logs/run14.log` … `logs/run16.log`; version 1 in `_superseded/v1-2026-10-23/`.
- **Is the hiring-manager reader right for me?** No. I don't want to show a hiring manager; it is
  irrelevant here. (Removed in the third version.)

## 2026-10-23 — third version: the whole trip

- **What I decided:** remove the hiring manager; TripMate plans the whole trip (places and activities
  at the destination), not only road journeys; I will build every feature; use Google APIs for hotel
  and flight prices.
- **What Claude found:** Google has no public flight or hotel price API (QPX Express closed in 2018),
  and Amadeus closed its free developer APIs on July 17, 2026. Google's Places and Routes APIs do give
  places, opening hours and travel times. The film now names price data as the main risk and plans a
  flight API such as Duffel plus a hotel partner API. The assignment still needs a target role, so it
  moved to "why this project".
- **Other changes:** Wanderlog replaced Google Maps as an alternative; the first piece is now the plan
  checker; a new beat shows each day grouped by area with opening hours and travel times.
- **Evidence:** `logs/run17.log` … `logs/run20.log`; version 2 in `_superseded/v2-2026-10-23/`.
- **How I will get flight and hotel prices:** I have not checked Duffel or a hotel API yet. I will
  look for other options too while building the project.

## 2026-10-24 — honest "already have"

- **What I said:** I have knowledge of Python, REST APIs, data pipelines and dashboards, but nothing
  built; everything will be built from scratch.
- **What changed:** B24 now says the project is mostly learning; B25 says I know these things but have
  no public projects yet, so TripMate is the first thing I build from scratch. The co-op dashboards and
  "repositories linked in the README" claims were removed from the film, the brief and the README.
- **Evidence:** `logs/run21.log`.
- **What I want to be able to show at the end:** I want TripMate to become the best stop for planning
  a trip.

## Human and AI contributions (summary)

- **Mine:** choosing TripMate and writing the project document; deciding to pitch the full list;
  asking for travel modes, hotel search and the places plan; making it a whole-trip planner; checking
  the alternatives myself.
- **In my words:** I spent a lot of time finding a new idea, because my previous idea did not look good
  to me after the feedback, so I chose one where I can use AI and build something with AI concepts.
- **Claude's:** the script draft, brief draft, research, route sample, all drawings, voice, renders,
  gate fixes, and this log's factual lines.
- **What I accepted, changed or rejected:** I accepted the name suggestion, TripMate; I liked the
  name. I rejected the idea of only focusing on a route finder.

## What I understand now / still don't

- **Now:** this project is good, and people can actually use it.
- **Still unsure:** live data for hotels and the rest.
