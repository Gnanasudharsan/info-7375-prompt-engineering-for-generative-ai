#!/usr/bin/env python3
"""make_sheet.py — beat_sheet.json for show-tell-tripmate-pitch.

SHOW-TELL: one drawn isometric illustration per beat, labels of 1-3 words, the voice explains.
Narration is Smit Patel's TripMate pitch, drafted with Claude from Smit's own project document
(2026-10-23) and to be edited by Smit before submission. It answers the assignment's seven questions
in order. No people are drawn (the skill forbids person icons): the two readers are their things
(a suitcase and car key).

Honesty rule: past tense only for what exists (the brief and one OSRM route sample, fetched
2026-10-23). Mock-ups carry a 'constructed' label on screen.
"""
import json
from pathlib import Path
HERE = Path(__file__).resolve().parent
SLUG = "show-tell-tripmate-pitch"
TITLE = "TripMate: Final Project Pitch"

def beat(bid, narration, cls, image):
    return {"beat_id": bid, "act": "show-tell", "lane": "manim", "proof_gate": "SHOW",
            "narration_text": narration, "estimated_duration_s": round(len(narration.split()) / 2.8, 1),
            "voice": "am_onyx", "engine": "kokoro",
            "shot": {"type": "GRAPHIC", "source": "own", "visual_intent": image, "manim": {"class": cls},
                     "motion_claim": image}}

B = [
 # ── Q1: what is it
 beat("B01", "Planning a trip means jumping between flight and hotel sites, maps, blogs and a calculator, and still guessing what to do there.",
      "B01_Juggle", "Four objects rise: a bed, a folded map, a blog page, a calculator; a road below ends in a question-mark pin."),
 beat("B02", "I'm Smit Patel, and this is my final project pitch: TripMate, an AI planner for the whole trip, from getting there to what you do each day.",
      "B02_Name", "The word 'TripMate' lands over a road; a small car drives along it to a pin."),
 beat("B03", "You give it where you start and where you're going, your dates, travelers, budget and interests.",
      "B03_Inputs", "Six input pills land on a form card: start, destination, dates, travelers, budget, interests."),
 beat("B04A", "First, it compares driving, buses, trains and flights by price and time, and suggests the best fit for your budget.",
      "B04A_Modes", "Four travel modes in a row (car, bus, train, plane), each with a cost bar and a time bar; one gets a check 'fits budget'; labelled 'constructed'."),
 beat("B04B", "It finds hotels within budget near the places you'll visit, says why each fits, and suggests a change if the total goes over.",
      "B04B_Hotels", "Three hotel cards land; two get checks and reason tags, one gets a cross; a budget bar with 'suggest a change'."),
 beat("B04C", "At the destination, Claude plans what to see and do each day from your interests, say beaches, forts and vegetarian food in Goa.",
      "B04C_Places", "Interest pills (beaches, forts, veg food) feed a three-day plan, mixed icons per day; labelled 'example'."),
 beat("B04D", "Each day groups nearby places, with real opening hours, travel times and meal breaks, so you can follow it.",
      "B04D_Day", "Three area circles of pins; a clock with 'open hours'; a line between stops with 'travel time'; a plate 'meals'."),
 beat("B04", "If you drive, it splits the road trip into driving days, picks where to sleep each night and why, and adds rest breaks.",
      "B04_Split", "A long road splits at two bed pins into Day 1, Day 2, Day 3; small break dots appear; label 'road trip'."),
 beat("B05", "When it's done, it will be a public GitHub repository: a React and Node web app with PostgreSQL, Claude and travel APIs, tests, and an evaluation report.",
      "B05_Deliver", "Four deliverables land: a repo crate, an app window, a test check, an eval report binder."),
 beat("B06", "It will also save, share and export trips, replan for weather, make packing lists, balance group preferences, and take voice requests.",
      "B06_Shelves", "Two shelves fill with solid blocks, 'core' and 'also'; a page 'full list' lands."),
 # ── Q2: why care
 beat("B07", "I looked at two alternatives. Wanderlog has an AI assistant and a budget tracker, but you add places and costs yourself. Roadtrippers shows where to look for stops, but you pick each one.",
      "B07_Alts", "Left: a folded map with a cursor adding a pin ('you add'). Right: a road with a dashed search ring and a pin ('you pick')."),
 beat("B08", "TripMate's difference: it builds the whole plan, treats your budget and limits as rules, and gives a reason for every choice.",
      "B08_Rule", "Three plan days under check gates; reason cards hang from the stops."),
 beat("B09", "On October 23rd, I pulled a real route from OpenStreetMap: Ahmedabad to Goa, about 1,036 kilometres, 12.7 hours of driving.",
      "B09_Real", "Two pins, Ahmedabad and Goa, joined by a road; a span '1,036 km'; '12.7 h driving'; a car drives; caption 'real route · OSRM · 2026-10-23'."),
 beat("B10", "With a five-hour daily limit, that's three driving days.",
      "B10_Days", "The same road splits into three days with two bed pins; labels '5 h limit' and '3 days'; labelled 'constructed'."),
 # ── Q3: who opens it
 beat("B11", "The person who opens it is a traveller planning a trip on a budget.",
      "B11_Reader", "A suitcase and a car key on the ground ('traveller')."),
 beat("B12", "In the first sixty seconds, they enter a trip, get a day-by-day plan, and open one choice to read why. This is a constructed mock-up.",
      "B12_Sixty", "A sixty-second ring sweeps; an app window fills with plan rows and a 'why' card; labelled 'constructed · mock-up'."),
 # ── how it works
 beat("B13", "The design rule: AI plans, code checks.",
      "B13_Rule", "A split stage: 'AI plans' on the left, 'code checks' on the right."),
 beat("B14", "Claude turns your request into structured requirements, asks for anything missing, then calls tools for fares, hotels, places and routes.",
      "B14_Tools", "A request page becomes a structured card; a question bubble; tool blocks 'fares', 'hotels', 'places' light in turn."),
 beat("B15", "Code totals the budget and checks opening hours, overlaps, travel times and driving limits. If a check fails, Claude must repair the plan.",
      "B15_Checks", "A server stack; four check boxes; three pass, the fourth gets a cross and a loop arrow sends it back to 'repair'."),
 beat("B16", "Every detail is labelled: verified, estimated, or AI suggestion.",
      "B16_Labels", "Three tags drop onto three plan rows: verified, estimated, AI suggestion."),
 beat("B17", "To change the trip, just say it, like add a beach day or find a cheaper hotel, and TripMate previews the change before saving.",
      "B17_Chat", "Chat bubbles; the plan shows a 'preview' with the changed day highlighted; a save check lands."),
 # ── Q4: what it proves
 beat("B18", "This proves prompt contracts, an agent loop with tool calls, source grounding, verification in code, and evaluation.",
      "B18_Proves", "Five skill blocks light in a row."),
 beat("B19", "The evidence will be tests and a twenty-trip evaluation counting over-budget plans, closed places and impossible timing against a plain chat answer, every miss reported.",
      "B19_Eval", "A grid of twenty small trip cards fills; some get a mark; a 'tests' binder and an 'eval report' page land."),
 # ── Q5: in, out, first
 beat("B20", "In scope: everything I've described. Out: TripMate will not book or pay for anything.",
      "B20_InOut", "Bins 'In' and 'Out'; blocks drop into In; a payment card in Out gets a cross."),
 beat("B21", "The first piece is the plan checker, in plain code. You'll know it ran when a test plants a closed place and an over-budget day, and the checker flags both.",
      "B21_First", "Three day cards in a 'First' row; a 'closed' sign on one, an overflowing budget bar on another; both get flags; 'test passes'."),
 # ── Q6: risk
 beat("B22", "What could sink it is price data: Google's APIs give places, hours and travel times, not flight or hotel prices, and Amadeus closed its free developer APIs in July.",
      "B22_Risk", "Three data crates: 'places' arrives solid; 'flight prices' and 'hotel prices' are dashed outlines with '?'."),
 beat("B23", "So I'll use a flight API such as Duffel and a hotel partner API, label unconfirmed prices as estimates, and test coverage on all twenty trips first.",
      "B23_Guard", "A 'flight API' tag and a 'hotel API' tag plug into the gaps; an 'estimate' label on a price row; twenty cards get coverage ticks."),
 # ── Q7: why this project
 beat("B24", "Why this project? I'm aiming for backend and AI engineering roles, and this one is mostly learning.",
      "B24_Why", "A road with a car and a suitcase; a beam tips toward a 'learn' block, away from a 'know' block."),
 beat("B25", "I already know Python, REST APIs, data pipelines and dashboards, but I have no public projects yet, so TripMate will be the first thing I build from scratch.",
      "B25_Have", "Pile one, 'already know': four blocks stack up; beside it a dashed empty crate 'no projects yet'."),
 beat("B26", "New to me: travel APIs, agent tool loops, constraint checking, plan evaluation, and a TypeScript back end.",
      "B26_New", "Pile two, 'learning': five blocks stack beside the first."),
 beat("B27", "Today, what exists is this pitch, my brief, and that route sample. Everything else is what I will build.",
      "B27_Exists", "Three solid pages 'pitch', 'brief', 'route sample'; ghost outlines 'will build' below."),
]

SPARSE_REASON = ("show-tell style: one drawn object or scene on a cream stage per beat, minimal labels, the voice carries "
                 "the explanation. Only underfill and clustered are waived; edge-bleed, empty-frame and contrast still apply.")
for b in B:
    b["qc"] = {"sparse_by_design": True, "sparse_reason": SPARSE_REASON}

B.append({"beat_id": "BOUT", "act": "outro", "lane": "manim", "proof_gate": "SHOW",
          "narration_text": "TripMate. A final project pitch by Smit Patel.", "estimated_duration_s": 4.0,
          "voice": "am_onyx", "engine": "kokoro",
          "shot": {"type": "GRAPHIC", "source": "own", "visual_intent": "Title restate and the author's name.",
                   "manim": {"class": "BOUT_Title"}},
          "qc": {"sparse_by_design": True, "sparse_reason": "Title card: the project name and the author's name on a cream stage; negative space is the card."}})

old = HERE / "beat_sheet.json"
if old.exists():
    prev = {b["beat_id"]: b for b in json.loads(old.read_text()).get("beats", [])}
    for b in B:
        p = prev.get(b["beat_id"], {})
        if p.get("narration_text") == b["narration_text"]:
            for k in ("audio_file", "actual_duration_s", "render_duration_s"):
                if k in p:
                    b[k] = p[k]

sheet = {"metadata": {
    "slug": SLUG, "title": TITLE, "topic": "FINAL PROJECT PITCH · INFO 7375", "skill": "show-tell", "style_preset": "show-tell",
    "channel": "none — student assignment", "persona": "Smit Patel (first person)", "author": "Smit Patel",
    "voice": "am_onyx", "voice_kokoro": "am_onyx", "engine": "kokoro",
    "clock": "narration", "palette": "claude", "register": "plain", "fps": 24, "aspect_ratio": "16:9",
    "caption_policy": "none",
    "bookend_exempt": ["cold-open", "bvdt", "bhtf"],
    "bookend_exempt_reason": "A student's project pitch, not a channel explainer: the pitch answers the assignment's seven questions and is the whole film. No hesitant-writer/terms/Your Turn bookends and no channel handle (the assignment says narrate as yourself, no instructor persona). Outro is an authored title card with the author's name.",
    "source_doc": "Smit Patel's TripMate project document (given in chat 2026-10-23) and the assignment's seven questions",
    "approvals": {}},
    "beats": B}
(HERE / "beat_sheet.json").write_text(json.dumps(sheet, indent=2, ensure_ascii=False) + "\n")
words = sum(len(b["narration_text"].split()) for b in B)
print(len(B), "beats;", words, "words; est", round(sum(b["estimated_duration_s"] for b in B)), "s")
